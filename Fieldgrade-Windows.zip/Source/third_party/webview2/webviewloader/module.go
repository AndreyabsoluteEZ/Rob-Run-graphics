//go:build windows

package webviewloader

import (
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"sync"
	"syscall"
	"unsafe"

	"golang.org/x/sys/windows"
)

var loader = sync.OnceValues(func() (windows.Handle, error) {
	executable, err := os.Executable()
	if err != nil {
		return 0, err
	}
	path := filepath.Join(filepath.Dir(executable), "WebView2Loader.dll")
	return windows.LoadLibraryEx(path, 0, windows.LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|windows.LOAD_LIBRARY_SEARCH_SYSTEM32)
})

func GetInstalledVersion() (string, error) {
	module, err := loader()
	if err != nil {
		return "", err
	}
	getVersion, err := windows.GetProcAddress(module, "GetAvailableCoreWebView2BrowserVersionString")
	if err != nil {
		return "", err
	}
	var version *uint16
	result, _, _ := syscall.SyscallN(getVersion, 0, uintptr(unsafe.Pointer(&version)))
	if version != nil {
		defer windows.CoTaskMemFree(unsafe.Pointer(version))
	}
	if uint32(result) != 0 {
		return "", fmt.Errorf("WebView2 HRESULT 0x%08X", uint32(result))
	}
	return windows.UTF16PtrToString(version), nil
}

func CreateCoreWebView2EnvironmentWithOptions(browserFolder, userFolder *uint16, options, completed uintptr) (uintptr, error) {
	module, err := loader()
	if err != nil {
		return 0, err
	}
	create, err := windows.GetProcAddress(module, "CreateCoreWebView2EnvironmentWithOptions")
	if err != nil {
		return 0, err
	}
	result, _, _ := syscall.SyscallN(create, uintptr(unsafe.Pointer(browserFolder)), uintptr(unsafe.Pointer(userFolder)), options, completed)
	runtime.KeepAlive(browserFolder)
	runtime.KeepAlive(userFolder)
	return uintptr(uint32(result)), nil
}
