module github.com/jchv/go-webview2

go 1.25.1

require golang.org/x/sys v0.36.0
