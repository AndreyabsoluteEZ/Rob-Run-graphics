package main

import (
	_ "embed"
	"encoding/json"
	"errors"
	"io"
	"os"
	"path/filepath"
	"runtime"
	"time"
	"unsafe"

	webview "github.com/jchv/go-webview2"
	"github.com/jchv/go-webview2/webviewloader"
	"golang.org/x/sys/windows"
)

//go:embed build/panel.html
var panel string

const settingsLimit = 64 * 1024

var (
	user32                = windows.NewLazySystemDLL("user32.dll")
	getSystemMetrics      = user32.NewProc("GetSystemMetrics")
	messageBox            = user32.NewProc("MessageBoxW")
	setWindowAttribute    = windows.NewLazySystemDLL("dwmapi.dll").NewProc("DwmSetWindowAttribute")
	errAlreadyRunning     = errors.New("Fieldgrade уже открыт.")
	errUnexpectedSettings = errors.New("Повреждённые настройки Fieldgrade.")
)

func singleInstance(name string) (windows.Handle, error) {
	label, err := windows.UTF16PtrFromString(name)
	if err != nil {
		return 0, err
	}
	handle, err := windows.CreateMutex(nil, false, label)
	if err != nil {
		if handle != 0 {
			_ = windows.CloseHandle(handle)
		}
		if errors.Is(err, windows.ERROR_ALREADY_EXISTS) {
			return 0, errAlreadyRunning
		}
		return 0, err
	}
	return handle, nil
}

func showError(message string) {
	title, _ := windows.UTF16PtrFromString("Fieldgrade")
	body, _ := windows.UTF16PtrFromString(message)
	messageBox.Call(0, uintptr(unsafe.Pointer(body)), uintptr(unsafe.Pointer(title)), 0x30)
}

func readSettings(path string) (string, error) {
	file, err := os.Open(path)
	if errors.Is(err, os.ErrNotExist) {
		return "", nil
	}
	if err != nil {
		return "", err
	}
	defer file.Close()
	data, err := io.ReadAll(io.LimitReader(file, settingsLimit+1))
	if err != nil {
		return "", err
	}
	if len(data) > settingsLimit || !json.Valid(data) {
		return "", errUnexpectedSettings
	}
	return string(data), nil
}

func saveSettings(path string, data string) error {
	if len(data) > settingsLimit || !json.Valid([]byte(data)) {
		return errUnexpectedSettings
	}
	temp, err := os.CreateTemp(filepath.Dir(path), "settings-*.tmp")
	if err != nil {
		return err
	}
	defer os.Remove(temp.Name())
	_, writeErr := temp.WriteString(data)
	closeErr := temp.Close()
	if err := errors.Join(writeErr, closeErr); err != nil {
		return err
	}
	from, err := windows.UTF16PtrFromString(temp.Name())
	if err != nil {
		return err
	}
	to, err := windows.UTF16PtrFromString(path)
	if err != nil {
		return err
	}
	return windows.MoveFileEx(from, to, windows.MOVEFILE_REPLACE_EXISTING|windows.MOVEFILE_WRITE_THROUGH)
}

func main() {
	if len(os.Args) == 2 && os.Args[1] == "--screen-worker" {
		runScreenWorker()
		return
	}
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()

	mutex, err := singleInstance(`Local\Fieldgrade.Editor.v1`)
	if err != nil {
		showError("Не удалось открыть программу. " + err.Error())
		return
	}
	defer windows.CloseHandle(mutex)

	version, err := webviewloader.GetInstalledVersion()
	if err != nil || version == "" {
		showError("Для запуска нужен Microsoft Edge WebView2 Runtime и файл WebView2Loader.dll рядом с Fieldgrade.exe. Распакуйте весь архив. Если компонент отсутствует, установите его с сайта Microsoft.")
		return
	}

	local, err := windows.KnownFolderPath(windows.FOLDERID_LocalAppData, windows.KF_FLAG_DEFAULT)
	if err != nil {
		showError("Не удалось открыть папку локальных настроек Windows.")
		return
	}
	dataPath := filepath.Join(local, "Fieldgrade")
	if err := os.MkdirAll(dataPath, 0700); err != nil {
		showError("Не удалось создать папку настроек Fieldgrade.")
		return
	}
	settingsPath := filepath.Join(dataPath, "settings.json")

	_ = os.Setenv("WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS", "--disable-background-networking --disable-component-update --no-first-run")
	width, _, _ := getSystemMetrics.Call(0)
	height, _, _ := getSystemMetrics.Call(1)
	view := webview.NewWithOptions(webview.WebViewOptions{
		DataPath:  filepath.Join(dataPath, "WebView2"),
		AutoFocus: true,
		WindowOptions: webview.WindowOptions{
			Title:  "Fieldgrade",
			Width:  uint(max(640, min(1320, int(width)-62))),
			Height: uint(max(480, min(950, int(height)-66))),
			Center: width >= 640 && height >= 480,
			IconId: 1,
		},
	})
	if view == nil {
		showError("Не удалось открыть интерфейс Microsoft Edge WebView2.")
		return
	}
	defer view.Destroy()
	view.SetSize(365, 430, webview.HintMin)
	if setWindowAttribute.Find() == nil {
		dark := int32(1)
		setWindowAttribute.Call(uintptr(view.Window()), 20, uintptr(unsafe.Pointer(&dark)), unsafe.Sizeof(dark))
	}

	var screen *screenClient
	defer func() {
		if screen != nil {
			screen.close()
			select {
			case <-screen.done:
			case <-time.After(2 * time.Second):
				// The worker will still restore the screen when its pipe closes.
			}
		}
	}()
	if err := view.Bind("screenCommand", func(action, payload string) (string, error) {
		switch action {
		case "load":
			return readSettings(settingsPath)
		case "save":
			return "", saveSettings(settingsPath, payload)
		case "apply":
			if len(payload) > 512 {
				return "", errInvalidAdjustment
			}
			var values adjustments
			if json.Unmarshal([]byte(payload), &values) != nil || !values.valid() {
				return "", errInvalidAdjustment
			}
			if screen == nil || screen.dead {
				screen, err = launchScreenWorker()
				if err != nil {
					return "", errUnavailable
				}
			}
			return "", screen.request(screenRequest{Action: "apply", Values: values})
		case "restore":
			if screen != nil && !screen.dead {
				return "", screen.request(screenRequest{Action: "restore"})
			}
			return "", nil
		default:
			return "", errUnexpectedSettings
		}
	}); err != nil {
		showError("Не удалось загрузить редактор Fieldgrade.")
		return
	}

	view.SetHtml(panel)
	view.Run()
}
