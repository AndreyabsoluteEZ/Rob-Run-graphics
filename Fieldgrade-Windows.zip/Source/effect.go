package main

type colorScreen interface {
	get() (matrix, error)
	set(matrix) error
}

type screenEffect struct {
	screen   colorScreen
	baseline matrix
	applied  matrix
	active   bool
}

func (effect *screenEffect) apply(settings adjustments) error {
	current, err := effect.screen.get()
	if err != nil {
		return err
	}
	baseline := effect.baseline
	if !effect.active || !current.almostEqual(effect.applied) {
		baseline = current
	}

	updated := baseline.then(settings.matrix())
	if err := effect.screen.set(updated); err != nil {
		return err
	}
	effect.baseline = baseline
	effect.applied = updated
	effect.active = true
	return nil
}

func (effect *screenEffect) restore() error {
	if !effect.active {
		return nil
	}
	current, err := effect.screen.get()
	// If Windows cannot report the current transform, still try restoring the
	// original transform. Leave independent changes by another app in place.
	if err != nil || current.almostEqual(effect.applied) {
		if err := effect.screen.set(effect.baseline); err != nil {
			return err
		}
	}
	effect.active = false
	return nil
}
