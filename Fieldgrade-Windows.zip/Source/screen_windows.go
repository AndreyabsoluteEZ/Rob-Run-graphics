package main

import (
	"bufio"
	"encoding/json"
	"errors"
	"io"
	"os"
	"os/exec"
	"runtime"
	"syscall"
	"time"
	"unsafe"

	"golang.org/x/sys/windows"
)

var (
	magnification        = windows.NewLazySystemDLL("Magnification.dll")
	magInitialize        = magnification.NewProc("MagInitialize")
	magUninitialize      = magnification.NewProc("MagUninitialize")
	magGetColor          = magnification.NewProc("MagGetFullscreenColorEffect")
	magSetColor          = magnification.NewProc("MagSetFullscreenColorEffect")
	errUnavailable       = errors.New("Windows не разрешила применить эффект. Проверьте, что вы работаете в локальном сеансе.")
	errScreenBusy        = errors.New("Fieldgrade уже меняет цвета в этом сеансе Windows.")
	errInvalidAdjustment = errors.New("Настройки цвета вне поддерживаемого диапазона.")
)

type windowsScreen struct{}

func (windowsScreen) get() (matrix, error) {
	var current matrix
	result, _, _ := magGetColor.Call(uintptr(unsafe.Pointer(&current[0])))
	if result == 0 {
		return current, errUnavailable
	}
	return current, nil
}

func (windowsScreen) set(value matrix) error {
	result, _, _ := magSetColor.Call(uintptr(unsafe.Pointer(&value[0])))
	if result == 0 {
		return errUnavailable
	}
	return nil
}

type screenRequest struct {
	Action string      `json:"action"`
	Values adjustments `json:"values"`
}

type screenResponse struct {
	Error string `json:"error,omitempty"`
}

func runScreenWorker() {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	encoder := json.NewEncoder(os.Stdout)
	writeResponse := func(err error) bool {
		var response screenResponse
		if err != nil {
			response.Error = err.Error()
		}
		return encoder.Encode(response) == nil
	}

	mutex, err := singleInstance(`Local\Fieldgrade.DisplayEffect.v1`)
	if err != nil {
		writeResponse(errScreenBusy)
		return
	}
	defer windows.CloseHandle(mutex)

	for _, proc := range []*windows.LazyProc{magInitialize, magUninitialize, magGetColor, magSetColor} {
		if proc.Find() != nil {
			writeResponse(errUnavailable)
			return
		}
	}
	initialized, _, _ := magInitialize.Call()
	if initialized == 0 {
		writeResponse(errUnavailable)
		return
	}
	defer magUninitialize.Call()

	effect := screenEffect{screen: windowsScreen{}}
	defer func() {
		for attempt := 0; attempt < 3; attempt++ {
			if effect.restore() == nil {
				return
			}
			time.Sleep(60 * time.Millisecond)
		}
	}()
	scanner := bufio.NewScanner(os.Stdin)
	scanner.Buffer(make([]byte, 2048), 2048)
	// The UI owns the write end of this pipe. Windows closes it if the UI
	// exits or is terminated, so restoration also runs after a UI crash.
	for scanner.Scan() {
		var request screenRequest
		if err := json.Unmarshal(scanner.Bytes(), &request); err != nil {
			writeResponse(errInvalidAdjustment)
			continue
		}
		var err error
		switch request.Action {
		case "apply":
			if !request.Values.valid() {
				err = errInvalidAdjustment
				break
			}
			err = effect.apply(request.Values)
		case "restore":
			err = effect.restore()
		default:
			err = errInvalidAdjustment
		}
		if !writeResponse(err) {
			return
		}
	}
}

type screenClient struct {
	input   io.WriteCloser
	decoder *json.Decoder
	output  *os.File
	done    chan struct{}
	dead    bool
}

func launchScreenWorker() (*screenClient, error) {
	path, err := os.Executable()
	if err != nil {
		return nil, err
	}
	command := exec.Command(path, "--screen-worker")
	command.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: windows.CREATE_NO_WINDOW}
	input, err := command.StdinPipe()
	if err != nil {
		return nil, err
	}
	output, childOutput, err := os.Pipe()
	if err != nil {
		input.Close()
		return nil, err
	}
	command.Stdout = childOutput
	err = command.Start()
	_ = childOutput.Close()
	if err != nil {
		input.Close()
		output.Close()
		return nil, err
	}
	client := &screenClient{input: input, output: output, decoder: json.NewDecoder(output), done: make(chan struct{})}
	go func() {
		_ = command.Wait()
		close(client.done)
	}()
	return client, nil
}

func (client *screenClient) close() {
	_ = client.input.Close()
	_ = client.output.Close()
	client.dead = true
}

func (client *screenClient) request(request screenRequest) error {
	type responseResult struct {
		err        error
		pipeBroken bool
	}
	response := make(chan responseResult, 1)
	go func() {
		if err := json.NewEncoder(client.input).Encode(request); err != nil {
			response <- responseResult{err: errUnavailable, pipeBroken: true}
			return
		}
		var result screenResponse
		if err := client.decoder.Decode(&result); err != nil {
			response <- responseResult{err: errUnavailable, pipeBroken: true}
			return
		}
		if result.Error != "" {
			response <- responseResult{err: errors.New(result.Error)}
			return
		}
		response <- responseResult{}
	}()
	select {
	case result := <-response:
		if result.pipeBroken {
			client.close()
		}
		return result.err
	case <-time.After(2500 * time.Millisecond):
		client.close()
		return errors.New("Windows не ответила вовремя. Попробуйте включить эффект снова.")
	}
}
