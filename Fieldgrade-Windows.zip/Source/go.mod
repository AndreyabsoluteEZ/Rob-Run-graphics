module fieldgrade.local/desktop

go 1.25.1

require github.com/jchv/go-webview2 v0.0.0-20260205173254-56598839c808

require golang.org/x/sys v0.36.0

replace github.com/jchv/go-webview2 => ./third_party/webview2
