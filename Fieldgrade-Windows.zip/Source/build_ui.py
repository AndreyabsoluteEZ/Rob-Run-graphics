from base64 import b64encode
from hashlib import sha256
from pathlib import Path

root = Path(__file__).resolve().parent
ui = root / "ui"
output = root / "build" / "panel.html"

def encode(filename):
    return b64encode((ui / filename).read_bytes()).decode("ascii")

def load(filename):
    return (ui / filename).read_text(encoding="utf-8")

style = load("panel.css")
for key, filename in {
    "MANROPE_LATIN": "manrope-latin.woff2",
    "MANROPE_CYRILLIC": "manrope-cyrillic.woff2",
    "SYMBOLS": "symbols.woff2",
}.items():
    style = style.replace("{{" + key + "}}", encode(filename))

script = load("panel.js")
for name in ("day", "shade", "frost", "amber", "custom"):
    script = script.replace("{{THUMB_" + name.upper() + "}}", encode(f"thumb-{name}.webp"))

page = load("panel.html")
for key, value in {
    "CSS": style,
    "JS": script,
    "SCRIPT_HASH": b64encode(sha256(script.encode("utf-8")).digest()).decode("ascii"),
    "SCENE": encode("scene.webp"),
    "ICON": encode("icon.ico"),
}.items():
    page = page.replace("{{" + key + "}}", value)

output.parent.mkdir(exist_ok=True)
output.write_text(page, encoding="utf-8", newline="\n")
print(f"{output.name}: {output.stat().st_size:,} bytes")
