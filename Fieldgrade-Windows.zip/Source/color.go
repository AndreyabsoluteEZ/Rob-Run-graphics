package main

import "math"

type adjustments struct {
	Brightness  int `json:"brightness"`
	Contrast    int `json:"contrast"`
	Saturation  int `json:"saturation"`
	Temperature int `json:"temperature"`
}

func (a adjustments) valid() bool {
	return a.Brightness >= -40 && a.Brightness <= 40 &&
		a.Contrast >= -40 && a.Contrast <= 40 &&
		a.Saturation >= -100 && a.Saturation <= 70 &&
		a.Temperature >= -50 && a.Temperature <= 50
}

// Windows multiplies row vectors [red, green, blue, alpha, 1] by this matrix.
type matrix [25]float32

func (a adjustments) matrix() matrix {
	saturation := 1 + float64(a.Saturation)/100
	contrast := 1 + float64(a.Contrast)/90
	temperature := float64(a.Temperature) / 250
	offset := float64(a.Brightness)/260 + (1-contrast)/2
	gains := [3]float64{1 + temperature, 1 - math.Abs(temperature)*0.10, 1 - temperature}
	gray := [3]float64{0.2126, 0.7152, 0.0722}
	result := matrix{18: 1, 24: 1}
	for output, gain := range gains {
		for input, weight := range gray {
			coefficient := weight * (1 - saturation)
			if input == output {
				coefficient += saturation
			}
			result[input*5+output] = float32(contrast * gain * coefficient)
		}
		result[20+output] = float32(gain * offset)
	}
	return result
}

func (left matrix) then(right matrix) matrix {
	var result matrix
	for row := range 5 {
		for col := range 5 {
			for component := range 5 {
				result[row*5+col] += left[row*5+component] * right[component*5+col]
			}
		}
	}
	return result
}

func (left matrix) almostEqual(right matrix) bool {
	for i, coefficient := range left {
		if math.Abs(float64(coefficient-right[i])) > 0.00001 {
			return false
		}
	}
	return true
}
