# Fieldgrade

Основной код Windows находится в `main_windows.go` и `screen_windows.go`. Цветовая матрица и логика восстановления находятся в `color.go` и `effect.go`. Интерфейс находится в каталоге `ui`.

При включении эффекта вспомогательный процесс запоминает текущую цветовую матрицу Windows и применяет коррекцию через Magnification API. После закрытия окна или обрыва канала процесс пытается восстановить исходную матрицу. Если другое приложение уже поменяло матрицу, Fieldgrade сохраняет его изменения.

## Сборка

Нужны Go 1.25.1 или новее и Python 3. Из папки Source выполните команды в PowerShell.

```powershell
python build_ui.py
go test .
$env:GOOS = "windows"
$env:GOARCH = "amd64"
$env:CGO_ENABLED = "0"
go build -buildvcs=false -trimpath -ldflags="-H windowsgui -s -w" -o Fieldgrade.exe .
```

Поместите официальный x64 `WebView2Loader.dll` рядом с полученным EXE. В архиве использована версия SDK `1.0.4314.35` из Microsoft.Web.WebView2. Для работы также нужен установленный Microsoft Edge WebView2 Runtime. [Пакет SDK](https://www.nuget.org/packages/Microsoft.Web.WebView2/1.0.4314.35)

Папка `third_party/webview2` содержит адаптированную версию go-webview2. Загрузчик открывает DLL из папки EXE через Windows LoadLibraryEx. Остальные изменения касаются обработки ошибок и ограничения доступа к командам Windows. [go-webview2](https://github.com/jchv/go-webview2/tree/56598839c808a2340edee99204db479f410e9bf4)

[Документация Microsoft по изменению цвета рабочего стола](https://learn.microsoft.com/windows/win32/api/magnification/nf-magnification-magsetfullscreencoloreffect)
