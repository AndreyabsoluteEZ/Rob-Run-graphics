"use strict";

const $ = (id) => document.getElementById(id);
const desktop = typeof window.screenCommand === "function";
const hasDownload = !desktop && ["http:", "https:"].includes(location.protocol);
const storageKey = "fieldgrade-settings-v1";
const limits = { brightness: [-40, 40], contrast: [-40, 40], saturation: [-100, 70], temperature: [-50, 50] };
const keys = Object.keys(limits);
const balance = { brightness: 0, contrast: 0, saturation: 0, temperature: 0 };
const presets = [
  { id: "day", name: "Ясный день", label: "Чётче и ярче", image: "{{THUMB_DAY}}", values: { brightness: 8, contrast: 12, saturation: 18, temperature: 6 } },
  { id: "shade", name: "Сумерки", label: "Светлее в тенях", image: "{{THUMB_SHADE}}", values: { brightness: 23, contrast: -10, saturation: 7, temperature: -5 } },
  { id: "frost", name: "Мороз", label: "Прохладные оттенки", image: "{{THUMB_FROST}}", values: { brightness: 6, contrast: 9, saturation: -16, temperature: -37 } },
  { id: "amber", name: "Золотой час", label: "Тёплые оттенки", image: "{{THUMB_AMBER}}", values: { brightness: 11, contrast: 5, saturation: 19, temperature: 38 } }
];
const model = {
  values: { ...presets[0].values },
  profiles: [],
  active: presets[0].id,
  compare: true,
  position: 50
};

const image = $("image");
const initialImage = image.src;
const initialAlt = image.alt;
const canvas = $("graded");
const context = canvas.getContext("2d");
const stage = $("stage");
const helpDialog = $("help-dialog");
const profileDialog = $("profile-dialog");
const profileName = $("profile-name");
const profileError = $("profile-error");
let sourcePixels;
let shadedPixels;
let previewFrame = 0;
let objectURL = "";
let imageRequest = 0;
let screenActive = false;
let screenBusy = false;
let screenTimer;
let saveTimer;
let toastTimer;
let thumbnail = "";

function cleanValues(input) {
  const clean = {};
  for (const key of keys) {
    const value = input?.[key];
    const [min, max] = limits[key];
    clean[key] = Number.isFinite(value) ? Math.max(min, Math.min(max, Math.round(value))) : 0;
  }
  return clean;
}

function sameValues(left, right) {
  return keys.every((key) => left[key] === right[key]);
}

function getProfiles() {
  return [...presets, ...model.profiles];
}

function hydrate(saved) {
  if (saved?.version !== 1) return;
  model.values = cleanValues(saved.values);
  model.compare = saved.compare !== false;
  const position = saved.position;
  model.position = Number.isFinite(position) ? Math.max(0, Math.min(100, position)) : 50;
  if (Array.isArray(saved.profiles)) {
    const ids = new Set(presets.map((preset) => preset.id));
    for (const entry of saved.profiles.slice(0, 32)) {
      if (!entry || typeof entry.id !== "string" || typeof entry.name !== "string") continue;
      const id = entry.id.slice(0, 80);
      if (!id || ids.has(id)) continue;
      const name = entry.name.trim().slice(0, 36);
      if (!name) continue;
      ids.add(id);
      model.profiles.push({ id, name, values: cleanValues(entry.values) });
    }
  }
  const savedProfile = getProfiles().find((profile) => profile.id === saved.active);
  model.active = savedProfile && sameValues(savedProfile.values, model.values) ? savedProfile.id : null;
}

function notify(message) {
  const toast = $("toast");
  clearTimeout(toastTimer);
  toast.textContent = message;
  toast.hidden = false;
  toastTimer = setTimeout(() => { toast.hidden = true; }, 3400);
}

function saveNow() {
  clearTimeout(saveTimer);
  const data = JSON.stringify({ version: 1, ...model });
  if (desktop) {
    window.screenCommand("save", data).catch(() => notify("Не удалось сохранить настройки на устройстве."));
    return;
  }
  try {
    localStorage.setItem(storageKey, data);
  } catch {
    notify("Браузер не разрешил сохранить настройки.");
  }
}

function saveSoon() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveNow, 160);
}

function icon(name) {
  const element = document.createElement("i");
  element.className = "icon";
  element.setAttribute("aria-hidden", "true");
  element.textContent = name;
  return element;
}

function syncProfile() {
  const active = getProfiles().find((profile) => profile.id === model.active);
  $("active-profile").textContent = active?.name ?? (sameValues(model.values, balance) ? "Исходные цвета" : "Ручная настройка");
  for (const button of $("profile-grid").querySelectorAll(".profile-pick")) {
    button.setAttribute("aria-pressed", String(model.active === button.dataset.id));
  }
}

function renderProfiles() {
  const grid = $("profile-grid");
  const cards = getProfiles().map((profile) => {
    const card = document.createElement("div");
    card.className = "profile-card";
    const pick = document.createElement("button");
    pick.type = "button";
    pick.className = "profile-pick";
    pick.dataset.id = profile.id;
    const picture = document.createElement("img");
    picture.className = "profile-shot";
    picture.alt = "";
    picture.src = "data:image/webp;base64," + (profile.image || thumbnail);
    const text = document.createElement("span");
    text.className = "profile-text";
    const title = document.createElement("span");
    title.className = "profile-name";
    title.textContent = profile.name;
    title.title = profile.name;
    const description = document.createElement("span");
    description.className = "profile-sub";
    description.textContent = profile.label || "Свой профиль";
    const check = document.createElement("span");
    check.className = "profile-check";
    check.append(icon("check"));
    text.append(title, description);
    pick.append(picture, text, check);
    pick.addEventListener("click", () => {
      model.values = { ...profile.values };
      model.active = profile.id;
      changed();
      saveNow();
    });
    card.append(pick);
    if (!profile.label) {
      card.classList.add("is-custom");
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "icon-button remove-profile";
      remove.setAttribute("aria-label", "Удалить профиль «" + profile.name + "»");
      remove.title = "Удалить профиль";
      remove.append(icon("delete"));
      remove.addEventListener("click", () => {
        model.profiles = model.profiles.filter((entry) => entry.id !== profile.id);
        if (model.active === profile.id) model.active = null;
        renderProfiles();
        $("save-button").focus();
        saveNow();
        notify("Профиль удалён.");
      });
      card.append(remove);
    }
    return card;
  });
  grid.replaceChildren(...cards);
  syncProfile();
}

function colorCoefficients(values) {
  const saturation = 1 + values.saturation / 100;
  const contrast = 1 + values.contrast / 90;
  const temperature = values.temperature / 250;
  const offset = values.brightness / 260 + (1 - contrast) / 2;
  const gains = [1 + temperature, 1 - Math.abs(temperature) * .10, 1 - temperature];
  const gray = [.2126, .7152, .0722];
  return gains.map((gain, row) => [
    ...gray.map((weight, col) => contrast * gain * (weight * (1 - saturation) + (row === col ? saturation : 0))),
    gain * offset * 255
  ]);
}

function renderPreview() {
  previewFrame = 0;
  if (!sourcePixels || !context || screenActive) return;
  const [red, green, blue] = colorCoefficients(model.values);
  const original = sourcePixels.data;
  const graded = shadedPixels.data;
  for (let index = 0; index < original.length; index += 4) {
    const r = original[index];
    const g = original[index + 1];
    const b = original[index + 2];
    graded[index] = red[0] * r + red[1] * g + red[2] * b + red[3];
    graded[index + 1] = green[0] * r + green[1] * g + green[2] * b + green[3];
    graded[index + 2] = blue[0] * r + blue[1] * g + blue[2] * b + blue[3];
    graded[index + 3] = 255;
  }
  context.putImageData(shadedPixels, 0, 0);
  stage.classList.add("has-preview");
}

function schedulePreview() {
  if (!previewFrame) previewFrame = requestAnimationFrame(renderPreview);
}

function prepareImage() {
  if (!context || !image.naturalWidth) return;
  const scale = Math.min(1, 1280 / image.naturalWidth, 1000 / image.naturalHeight);
  canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
  canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
  context.fillStyle = "#24262d";
  context.fillRect(0, 0, canvas.width, canvas.height);
  context.drawImage(image, 0, 0, canvas.width, canvas.height);
  sourcePixels = context.getImageData(0, 0, canvas.width, canvas.height);
  shadedPixels = context.createImageData(canvas.width, canvas.height);
  renderPreview();
}

function syncControls() {
  for (const key of keys) {
    const input = $(key);
    const value = model.values[key];
    const [min, max] = limits[key];
    const display = value > 0 ? "+" + value : String(value).replace("-", "−");
    input.value = value;
    input.style.setProperty("--point", ((value - min) / (max - min)) * 100 + "%");
    $(key + "-value").value = display;
  }
}

function syncPreviewMode() {
  const compare = model.compare && !screenActive;
  stage.classList.toggle("is-comparing", compare);
  stage.classList.toggle("acting", screenActive);
  stage.style.setProperty("--split", model.position + "%");
  $("compare-position").value = model.position;
  $("compare-mode").setAttribute("aria-pressed", String(compare));
  $("result-mode").setAttribute("aria-pressed", String(!compare));
  $("compare-mode").disabled = screenActive;
  $("result-mode").disabled = screenActive;
  const screenButton = $("screen-button");
  screenButton.dataset.active = String(screenActive);
  screenButton.setAttribute("aria-pressed", String(screenActive));
  $("screen-label").textContent = screenActive ? "Снять эффект" : "Применить к экрану";
  $("mode-status").dataset.active = String(screenActive);
  $("mode-label").textContent = screenActive ? "Эффект на экране" : "В реальном времени";
}

function changed() {
  syncControls();
  syncProfile();
  schedulePreview();
  if (screenActive && !screenBusy) {
    clearTimeout(screenTimer);
    screenTimer = setTimeout(() => {
      if (screenActive && !screenBusy) updateScreen(true);
    }, 70);
  }
}

async function updateScreen(enabled, announce = false) {
  try {
    await window.screenCommand(enabled ? "apply" : "restore", JSON.stringify(model.values));
    screenActive = enabled;
    syncPreviewMode();
    schedulePreview();
    if (announce) notify(enabled ? "Цвета рабочего стола обновлены." : "Цвета рабочего стола восстановлены.");
  } catch (error) {
    notify(typeof error === "string" ? error : "Windows не смогла изменить цвета экрана.");
  }
}

for (const key of keys) {
  $(key).addEventListener("input", (event) => {
    model.values[key] = Number(event.currentTarget.value);
    if (model.active && !sameValues(model.values, getProfiles().find((profile) => profile.id === model.active).values)) {
      model.active = null;
    }
    changed();
    saveSoon();
  });
  $(key).addEventListener("change", saveNow);
}

$("reset-button").addEventListener("click", () => {
  model.values = { ...balance };
  model.active = null;
  changed();
  saveNow();
  notify("Исходные настройки восстановлены.");
});

for (const [id, value] of [["compare-mode", true], ["result-mode", false]]) {
  $(id).addEventListener("click", () => {
    model.compare = value;
    syncPreviewMode();
    saveNow();
  });
}
$("compare-position").addEventListener("input", (event) => {
  model.position = Number(event.currentTarget.value);
  stage.style.setProperty("--split", model.position + "%");
  saveSoon();
});
$("compare-position").addEventListener("change", saveNow);

$("screen-button").addEventListener("click", async () => {
  if (!desktop) {
    $("help-heading").textContent = "Применение к экрану в Windows";
    helpDialog.showModal();
    return;
  }
  if (screenBusy) return;
  screenBusy = true;
  $("screen-button").disabled = true;
  clearTimeout(screenTimer);
  const requested = { ...model.values };
  await updateScreen(!screenActive, true);
  screenBusy = false;
  $("screen-button").disabled = false;
  if (screenActive && !sameValues(requested, model.values)) changed();
});

$("help-button").addEventListener("click", () => {
  $("help-heading").textContent = "Как работает Fieldgrade";
  helpDialog.showModal();
});
for (const button of document.querySelectorAll(".dialog-close")) {
  button.addEventListener("click", () => button.closest("dialog").close());
}

if (desktop) {
  for (const name of ["dragover", "drop"]) {
    window.addEventListener(name, (event) => event.preventDefault());
  }
}
image.addEventListener("load", prepareImage);
$("image-button").addEventListener("click", () => $("image-file").click());
$("image-file").addEventListener("change", async (event) => {
  const input = event.currentTarget;
  const file = input.files[0];
  input.value = "";
  if (!file) return;
  const request = ++imageRequest;
  if (file.size > 20 * 1024 * 1024 || !/\.(png|jpe?g|webp)$/i.test(file.name)) {
    notify("Выберите изображение PNG, JPEG или WebP до 20 МБ.");
    return;
  }
  const nextURL = URL.createObjectURL(file);
  const probe = new Image();
  probe.src = nextURL;
  try {
    await probe.decode();
    if (probe.naturalWidth * probe.naturalHeight > 32_000_000) {
      throw new Error("too many pixels");
    }
  } catch {
    URL.revokeObjectURL(nextURL);
    if (request === imageRequest) notify("Не удалось открыть фото. Проверьте формат и разрешение.");
    return;
  }
  if (request !== imageRequest) {
    URL.revokeObjectURL(nextURL);
    return;
  }
  if (objectURL) URL.revokeObjectURL(objectURL);
  objectURL = nextURL;
  stage.classList.remove("has-preview");
  image.alt = file.name;
  image.src = objectURL;
  $("image-name").textContent = file.name;
  $("restore-image").hidden = false;
});
$("restore-image").addEventListener("click", () => {
  imageRequest++;
  if (objectURL) URL.revokeObjectURL(objectURL);
  objectURL = "";
  stage.classList.remove("has-preview");
  image.src = initialImage;
  image.alt = initialAlt;
  $("image-name").textContent = "Горная станция";
  $("restore-image").hidden = true;
  $("image-button").focus();
});

$("save-button").addEventListener("click", () => {
  if (model.profiles.length >= 32) {
    notify("Можно сохранить до 32 своих профилей.");
    return;
  }
  profileName.value = "";
  profileError.hidden = true;
  profileDialog.showModal();
  profileName.focus();
});
$("profile-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const name = profileName.value.trim();
  if (!name) {
    profileError.textContent = "Введите название профиля.";
    profileError.hidden = false;
    return;
  }
  if (getProfiles().some((profile) => profile.name.toLocaleLowerCase("ru") === name.toLocaleLowerCase("ru"))) {
    profileError.textContent = "Профиль с таким названием уже есть.";
    profileError.hidden = false;
    return;
  }
  const profile = { id: crypto.randomUUID ? crypto.randomUUID() : "user-" + Date.now(), name, values: { ...model.values } };
  model.profiles.push(profile);
  model.active = profile.id;
  renderProfiles();
  profileDialog.close();
  saveNow();
  notify("Профиль сохранён.");
});

function syncNavigation() {
  const showProfiles = location.hash === "#profiles";
  $("editor-link").toggleAttribute("aria-current", !showProfiles);
  $("profiles-link").toggleAttribute("aria-current", showProfiles);
  (showProfiles ? $("profiles-link") : $("editor-link")).setAttribute("aria-current", "location");
}
window.addEventListener("hashchange", syncNavigation);

async function initialize() {
  thumbnail = "{{THUMB_CUSTOM}}";
  $("download-link").hidden = !hasDownload;
  $("help-download").hidden = !hasDownload;
  if (hasDownload) {
    $("screen-label").textContent = "Применить к экрану";
    $("screen-button").title = "Доступно в приложении для Windows";
  }
  if (desktop) {
    $("screen-button").disabled = true;
    for (const id of ["reset-button", "save-button", ...keys, "compare-mode", "result-mode", "compare-position"]) $(id).disabled = true;
  }
  try {
    const raw = desktop ? await window.screenCommand("load", "") : localStorage.getItem(storageKey);
    if (raw) hydrate(JSON.parse(raw));
  } catch {
    notify("Не удалось загрузить сохранённые настройки.");
  } finally {
    for (const id of ["screen-button", "reset-button", "save-button", ...keys, "compare-mode", "result-mode", "compare-position"]) $(id).disabled = false;
    syncControls();
    syncPreviewMode();
    renderProfiles();
    if (image.complete) prepareImage();
    syncNavigation();
  }
}
initialize();
