package main

import (
	"errors"
	"testing"
)

type fakeColorScreen struct {
	current matrix
	getErr  error
	setErr  error
}

func (s *fakeColorScreen) get() (matrix, error) { return s.current, s.getErr }

func (s *fakeColorScreen) set(value matrix) error {
	if s.setErr != nil {
		return s.setErr
	}
	s.current = value
	return nil
}

func TestScreenEffectDoesNotStackAndRestoresBaseline(t *testing.T) {
	original := adjustments{Temperature: 10}.matrix()
	screen := &fakeColorScreen{current: original}
	effect := screenEffect{screen: screen}
	first := adjustments{Brightness: 8, Saturation: 18}
	second := adjustments{Brightness: 23, Contrast: -10}
	for _, settings := range []adjustments{first, second} {
		if err := effect.apply(settings); err != nil {
			t.Fatal(err)
		}
		if want := original.then(settings.matrix()); !screen.current.almostEqual(want) {
			t.Fatal("the current adjustment must run after the original matrix")
		}
	}
	if err := effect.restore(); err != nil {
		t.Fatal(err)
	}
	if !screen.current.almostEqual(original) || effect.active {
		t.Fatal("restoration did not return the original matrix")
	}
}

func TestScreenEffectRespectsChangesMadeElsewhere(t *testing.T) {
	screen := &fakeColorScreen{current: adjustments{}.matrix()}
	effect := screenEffect{screen: screen}
	if err := effect.apply(adjustments{Contrast: 15}); err != nil {
		t.Fatal(err)
	}
	external := adjustments{Brightness: -10}.matrix()
	screen.current = external
	if err := effect.restore(); err != nil {
		t.Fatal(err)
	}
	if !screen.current.almostEqual(external) {
		t.Fatal("restoration replaced a newer system transform")
	}
}

func TestScreenEffectRetriesFailedRestoration(t *testing.T) {
	original := adjustments{}.matrix()
	screen := &fakeColorScreen{current: original}
	effect := screenEffect{screen: screen}
	if err := effect.apply(adjustments{Contrast: 15}); err != nil {
		t.Fatal(err)
	}
	screen.setErr = errors.New("test failure")
	if err := effect.restore(); err == nil || !effect.active {
		t.Fatal("a failed restoration should remain pending")
	}
	screen.setErr = nil
	screen.getErr = errors.New("test failure")
	if err := effect.restore(); err != nil {
		t.Fatal(err)
	}
	if !screen.current.almostEqual(original) {
		t.Fatal("the baseline should be restored when the current matrix cannot be read")
	}
}

func TestSaturationZeroesToLuminance(t *testing.T) {
	coefficients := adjustments{Saturation: -100}.matrix()
	for output := range 3 {
		if coefficients[output] != .2126 || coefficients[5+output] != .7152 || coefficients[10+output] != .0722 {
			t.Fatal("each grayscale channel should use the correct luminance coefficients")
		}
	}
}
